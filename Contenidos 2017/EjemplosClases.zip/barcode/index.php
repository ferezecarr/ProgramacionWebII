<?php
require_once('barcode.inc.php'); 
$code_number = '1234567mnb,n890';
new barCodeGenrator($code_number,0,'hello.gif'); 
?> 