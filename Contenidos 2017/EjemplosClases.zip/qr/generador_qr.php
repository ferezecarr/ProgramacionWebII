<?php

include("Conectarbd.php");
include("phpqrcode/qrlib.php");

QRcode::png('xdlfjhsdfljghsfd',false,QR_ECLEVEL_Q,3);


QRcode::png('xdlfjhsdfljghsfd','cacho.png');





?>
