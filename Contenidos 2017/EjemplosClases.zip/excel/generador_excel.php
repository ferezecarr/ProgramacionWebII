<?php
// Header para descargar la tabla como archivo Excel
header("Content-type: application/vnd.ms-excel; name='excel'; charset=utf-8");
header("Content-Disposition: filename=ejemplo.xls");
header("Pragma: no-cache");
header("Expires: 0");
include('Conectarbd.php');

echo "<table><tr><td colspan='2'>Especialidades</td></tr>";

$sql = "select especialidades.idEspecialidad, especialidades.descripcionEspecialidad from especialidades";
$con = New conectarBD();
$reg = $con->ConsultaSelect($sql);
echo "<tr>";
echo "<th>ID</th>";
echo "<th>Descripcion</th>";
echo "</tr>";

while($fila = mysqli_fetch_assoc($reg)) {
    echo "<tr>";
    echo "<td>" . $fila["idEspecialidad"]. "</td>";
    echo "<td>" . $fila["descripcionEspecialidad"]. "</td>";
    echo "</tr>";
}
echo "</table>";
?>
