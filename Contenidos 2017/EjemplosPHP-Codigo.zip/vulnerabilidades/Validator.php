<?php

/**
 * Clase utilizada para validacion de variables.
 * Reglas disponibles:
 *      required | max_len | min_len | range_len | exact_len | email | url |
 *      numeric | integer | float | boolean | min | max | range |
 *
 * date | file
 *
 * @author: Leandro Morrone (basado en https://github.com/Wixel/GUMP)
 */
class v {

    private static $allowedTags = '<br><p><a><strong><b><i><em><img><blockquote><code><dd><dl><hr><div><h1><h2><h3><h4><h5><h6><label><ul><li><span><sub><sup><table><tr><td><th><tbody><thead>';

    /**
     * Metodo de validacion de parametros en un array asociativo.
     * @param array $input Array de entrada, por ejemplo $_GET o $_POST.
     * @param string $field Nombre del campo a validar dentro del array.
     * @param string $rulesStr Reglas de validacion.
     *          Sintaxis: [regla[,parametro]*[|regla[,parametro]*]*]
     *          Si no se ingresa el parametro, solo se valida que exista el campo en el array.
     * @return bool Si se cumplen todas las reglas de validacion sobre el valor.
     */
    public static function validate($input, $field, $rulesStr = '') {

        $isValid = true;

        // Si el input es un array, y existe el campo en el array
        if (is_array($input) && array_key_exists($field, $input) === true) {

            // Si no recibo parametros solo se verifica que exista el campo
            if ($rulesStr == '') {
                return $isValid;
            }

            // Separo las reglas
            $rules = explode("|", $rulesStr);

            foreach ($rules as $rule) {

                $method = null;
                $params = null;

                // Verifico si la regla tiene parametros
                if (strstr($rule, ',') !== false) {
                    $ruleArr = explode(',', $rule);
                    $params = array_slice($ruleArr, 1);
                    $method = 'validate_' . $ruleArr[0];
                } else {
                    $method = 'validate_' . $rule;
                }

                // Llamo al metodo de validacion de la regla
                if (method_exists(__CLASS__, $method)) {
                    $isValid = $isValid && self::$method($input[$field], $params);
                } else {
                    // Si el metodo no existe, la validacion falla
                    Log::warning("validate", "La regla de validacion no existe: $rule");
                    $isValid = false;
                }
            }

        } else {
            $isValid = false;
        }
        //die();
        return $isValid;
    }


    /*
     * Regla: required
     * Valida que un el valor sea distinto de vacio o nulo o espacios en blanco.
     */
    public static function validate_required($value, $params = null) {
        $value = !is_array($value) ? trim($value) : $value;
        return isset($value) && (
            !empty($value) || $value === false || $value === 0 || $value === 0.0 || $value === '0');
    }


    /*
     * Regla: max_len
     * Parametros: longitud maxima
     * Valida que el valor tenga una longitud o cantidad de elementos menor a la especificada.
     */
    public static function validate_max_len($value, $params = null) {
        if (!isset($value)) {
            return true;
        }
        $maxLen = count($params) > 0 ? intval($params[0]) : 0;
        return
            is_array($value) && count($value) <= $maxLen ||
            !is_array($value) && strlen($value) <= $maxLen;
    }


    /*
     * Regla: min_len
     * Parametros: longitud minima
     * Valida que el valor tenga una longitud o cantidad de elementos mayor a la especificada.
     */
    public static function validate_min_len($value, $params = null) {
        if (!isset($value)) {
            return true;
        }
        $minLen = count($params) > 0 ? intval($params[0]) : 0;
        return
            is_array($value) && count($value) >= $minLen ||
            !is_array($value) && strlen($value) >= $minLen;
    }


    /*
     * Regla: range_len
     * Parametros: longitud minima, longitud maxima
     * Valida que la longitud o cantidad de elementos del valor este entre el minimo y maximo especificados.
     */
    public static function validate_range_len($value, $params = null) {
        if (!isset($value)) {
            return true;
        }
        $minLen = count($params) > 1 ? intval($params[0]) : 0;
        $maxLen = count($params) > 1 ? intval($params[1]) : 0;
        return
            is_array($value) && count($value) >= $minLen && count($value) <= $maxLen ||
            !is_array($value) && strlen($value) >= $minLen && strlen($value) <= $maxLen;
    }


    /*
     * Regla: exact_len
     * Parametros: longitud exacta
     * Valida que el valor tenga una longitud o cantidad de elementos igual a la especificada.
     */
    public static function validate_exact_len($value, $params = null) {
        if (!isset($value)) {
            return true;
        }
        $exactLen = count($params) > 0 ? intval($params[0]) : 0;
        return
            is_array($value) && count($value) == $exactLen ||
            !is_array($value) && strlen($value) == $exactLen;
    }


    /*
     * Regla: email
     * Valida que el valor tenga formato de cuenta de email.
     */
    public static function validate_email($value, $params = null) {
        if (!isset($value) || empty($value)) {
            return true;
        }
        return filter_var($value, FILTER_VALIDATE_EMAIL) !== false;
    }


    /*
     * Regla: url
     * Valida que el valor tenga formato url correcto.
     */
    public static function validate_url($value, $params = null) {
        if (!isset($value) || empty($value)) {
            return true;
        }
        return filter_var($value, FILTER_VALIDATE_URL) !== false;
    }


    /*
     * Regla: numeric
     * Valida que el valor sea numerico.
     */
    public static function validate_numeric($value, $params = null) {
        if (!isset($value) || empty($value)) {
            return true;
        }
        return is_numeric($value);
    }


    /*
     * Regla: integer
     * Valida que el valor sea un numero entero.
     */
    public static function validate_integer($value, $params = null) {
        if (!isset($value) || empty($value)) {
            return true;
        }
        return filter_var($value, FILTER_VALIDATE_INT) !== false;
    }


    /*
     * Regla: float
     * Valida que el valor sea un numero decimal.
     */
    public static function validate_float($value, $params = null) {
        if (!isset($value) || empty($value)) {
            return true;
        }
        return filter_var($value, FILTER_VALIDATE_FLOAT) !== false;
    }


    /*
     * Regla: boolean
     * Valida que el valor sea de tipo booleano.
     */
    public static function validate_boolean($value, $params = null) {
        if (!isset($value) || empty($value) && $value !== 0) {
            return true;
        }
        return $value === true || $value === false;
    }


    /*
     * Regla: max
     * Parametros: valor maximo
     * Valida que el valor sea numerico y menor al numero especificado.
     */
    public static function validate_max($value, $params = null) {
        if (!isset($value)) {
            return true;
        }
        $max = count($params) > 0 && is_numeric($params[0]) ? $params[0] : INF;
        return is_numeric($value) && $value <= $max;
    }


    /*
     * Regla: min
     * Parametros: valor minimo
     * Valida que el valor sea numerico y mayor al numero especificado.
     */
    public static function validate_min($value, $params = null) {
        if (!isset($value)) {
            return true;
        }
        $min = count($params) > 0 && is_numeric($params[0]) ? $params[0] : 0;
        return is_numeric($value) && $value >= $min;
    }


    /*
     * Regla: range
     * Parametros: valor minimo, valor maximo
     * Valida que el valor sea numerico y se encuentre entre los valores especificados.
     */
    public static function validate_range($value, $params = null) {
        if (!isset($value)) {
            return true;
        }
        $min = count($params) > 1 && is_numeric($params[0]) ? $params[0] : 0;
        $max = count($params) > 1 && is_numeric($params[1]) ? $params[1] : INF;
        return is_numeric($value) && $value >= $min && $value <= $max;
    }


    /**
     * Saneamiento de texto para base de datos: anti scripting y addslashes.
     * Para aplicar a los valores de texto recibidos por formulario.
     * @param string $value Texto.
     * @return string Texto saneado.
     */
    public static function sanitize($value) {

        // Elimino los tags de client side scripting
        $value = preg_replace('#<script(.*?)>(.*?)</script>#is', '', $value);
        $value = preg_replace('#<iframe(.*?)>(.*?)</iframe>#is', '', $value);

        // Escapeo los caracteres especiales (" ' \ \n \t)
        $value = addslashes($value);

        return $value;
    }


    /**
     * Saneamiento de texto para javascript: json_encode.
     * Para imprimir contenido de PHP dentro de javascript.
     * @param string $value Texto.
     * @return string Texto saneado.
     */
    public static function sanitizeJS($value) {

        // Escapeo saltos de linea y caracteres especiales
        // Uso el substr para eliminar las comillas que json_encode inserta al inicio y al final
        $value = substr(json_encode($value), 1, -1);

        return $value;
    }


    /**
     * Saneamiento de arrays para base de datos: anti scripting y addslashes.
     * Para aplicar a los valores recibidos por formulario.
     * @param array $array Array de formulario, ej: $_POST.
     * @return array Array saneado.
     */
    public static function sanitizeAll($array) {

        array_walk_recursive($array, function(&$value) {

            // Elimino los tags de client side scripting
            $value = preg_replace('#<script(.*?)>(.*?)</script>#is', '', $value);
            $value = preg_replace('#<iframe(.*?)>(.*?)</iframe>#is', '', $value);

            // Escapeo los caracteres especiales (" ' \ \n \t)
            $value = addslashes($value);
        });

        return $array;
    }


    /**
     * Codifica en HTML el texto solicitado (reemplaza caracteres especiales por entidades).
     * Para aplicar a un valor se vaya a imprimir por pantalla.
     * @param string $value Texto.
     * @return string Texto codificado en HTML.
     */
    public static function htmlEncode($value) {

        // Elimino los tags de client side scripting
        $value = preg_replace('#<script(.*?)>(.*?)</script>#is', '', $value);
        $value = preg_replace('#<iframe(.*?)>(.*?)</iframe>#is', '', $value);

        // Codifico los caracteres especiales en formato html
        //$value = htmlspecialchars($value, ENT_QUOTES | ENT_IGNORE, "UTF-8");
        $value = htmlspecialchars($value, ENT_QUOTES, "UTF-8");

        return $value;
    }


    /**
     * Codifica en HTML los valores del array solicitado (reemplaza caracteres especiales por entidades).
     * Para aplicar a los valor de un array que se vaya a imprimir por pantalla, ej: resultado de una query.
     * @param array $array Array a codificar.
     * @return array Array codificado en HTML.
     */
    public static function htmlEncodeAll($array) {

        array_walk_recursive($array, function(&$value) {

            // Elimino los tags de client side scripting
            $value = preg_replace('#<script(.*?)>(.*?)</script>#is', '', $value);
            $value = preg_replace('#<iframe(.*?)>(.*?)</iframe>#is', '', $value);

            // Codifico los caracteres especiales en formato html
            //$value = htmlspecialchars($value, ENT_QUOTES | ENT_IGNORE, "UTF-8");
            $value = htmlspecialchars($value, ENT_QUOTES, "UTF-8");

        });

        return $array;
    }


    /**
     * Elimina los tags HTML del texto ingresado.
     * @param string $value Texto HTML.
     * @param bool $all Si se eliminan todos los tags o solo los que no estan definidos en $allowedTags
     * @return string Texto limpio de tags.
     */
    public static function htmlStrip($value, $all = false) {

        // Elimino los tags de client side scripting
        $value = preg_replace('#<script(.*?)>(.*?)</script>#is', '', $value);
        $value = preg_replace('#<iframe(.*?)>(.*?)</iframe>#is', '', $value);

        if ($all) {
            // Elimino todos los tags html
            $value = strip_tags($value);
        } else {
            // Elimino los tags html excepto los especificados en $allowedTags
            $value = strip_tags($value, self::$allowedTags);
        }

        return $value;
    }


    /**
     * Elimina los tags HTML del array ingresado.
     * @param array $array Texto HTML.
     * @param bool $all Si se eliminan todos los tags o solo los que no estan definidos en $allowedTags
     * @return array Array limpio de tags.
     */
    public static function htmlStripAll($array, $all = false) {

        array_walk_recursive($array, function(&$value) use(&$all) {

            // Elimino los tags de client side scripting
            $value = preg_replace('#<script(.*?)>(.*?)</script>#is', '', $value);
            $value = preg_replace('#<iframe(.*?)>(.*?)</iframe>#is', '', $value);

            if ($all) {
                // Elimino todos los tags html
                $value = strip_tags($value);
            } else {
                // Elimino los tags html excepto los especificados en $allowedTags
                $value = strip_tags($value, self::$allowedTags);
            }

        });

        return $array;
    }

}