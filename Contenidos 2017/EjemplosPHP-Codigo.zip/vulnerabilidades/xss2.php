<?php

$usuario = $_POST["nombre"];
$texto = $_POST["texto"];

$usuario = strip_tags($usuario);
$texto = strip_tags($texto);

echo $usuario . "<br><br>";
echo $texto;

/* cerrar conexión */

?>
