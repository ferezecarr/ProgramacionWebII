<?php

$usuario = $_POST["nombre"];
$texto = $_POST["texto"];

echo $usuario . "<br><br>";
echo $texto;

/* cerrar conexión */

?>
