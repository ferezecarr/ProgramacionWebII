<?php
$link = mysqli_connect("localhost", "root", "", "demo");

/* verificar conexión */
if (mysqli_connect_errno()) {
    printf("Fallo conexion: %s\n", mysqli_connect_error());
    exit();
}

$usuario = $_POST["nombre"];
$clave = md5($_POST["clave"]);

$sql = "SELECT * FROM login WHERE nick = '" . $usuario . "' and clave = '" . $clave . "'";
$resultado = mysqli_query($link,$sql);
if($row = mysqli_fetch_array($resultado)) {
            echo $sql . "<BR>";
            echo "Login Correcto";
} else {
            echo $sql . "<BR>";
            echo "Login Incorrecto";
}

/* cerrar conexión */

// admin@demo' or 1=1 and '
mysqli_close($link);
?>
