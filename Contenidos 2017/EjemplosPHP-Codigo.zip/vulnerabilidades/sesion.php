<?php

ini_set('session.cookie_lifetime',0);
ini_set('session.hash_bits_per_character','4');
ini_set('session.hash_function', 'sha256');
session_name("PRUEBASESSION");
session_start();

phpinfo();


?>
