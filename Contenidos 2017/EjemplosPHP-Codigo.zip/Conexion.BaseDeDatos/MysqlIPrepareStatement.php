<?php
$server = "localhost";
$usuario = "root";
$password = "";
$db = "enpatagonia";

// Create connection
$conn = new mysqli($server, $usuario, $password, $db);

if ($conn->connect_error) {
    die("Fallo la conexion: " . $conn->connect_error);
}

$stmt = $conn->prepare("INSERT INTO especialidades (descripcionEspecialidad) VALUES (?)");
$stmt->bind_param("s", $descripcion);

// set parameters and execute
$descripcion = "Prueba 1";
$stmt->execute();

$descripcion = "Prueba 2";
$stmt->execute();

$descripcion = "Prueba 3";
$stmt->execute();

$stmt->close();
$conn->close();
?>