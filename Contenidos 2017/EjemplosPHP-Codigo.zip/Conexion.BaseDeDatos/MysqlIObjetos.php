<?php

$server = "localhost";
$usuario = "root";
$password = "";
$db = "enpatagonia";

$conn = new mysqli($server, $usuario, $password);


if ($conn->connect_error) {
    die("Fallo la conexion: " . $conn->connect_error);
}

echo "Conexion Correcta<br>";
$conn->select_db($db);

$sql = "select * from especialidades";

if($resultado = $conn->query($sql)) {
	echo "query correcta<br>";
	$numero_de_filas = $resultado->num_rows;
	echo $numero_de_filas . "<br>";
	$todas = $resultado->fetch_all();
	var_dump($todas);
	$resultado->data_seek(0);
	while($fila = $resultado->fetch_assoc()){
			echo $fila["idEspecialidad"] . "<br><br>";
	}
	$resultado->free();

	$sql = "insert into especialidades (descripcionEspecialidad) values (?)";

	if($resultado = $conn->query($sql)) {
		echo "Clave insertada: " . $conn->insert_id;
	} else {
		echo $conn->error;
	}

	$conn->close();



} else {
	echo "error en la query" . $conn->error;
}



?>