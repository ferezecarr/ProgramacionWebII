<?php


$conexion = mysqli_connect("localhost","root","","enpatagonia") or die("sfgljasdflkjashfglksjhfd");
$sql = "select * from especialidades";
$resultado = mysqli_query($conexion,$sql);


while($fila = mysqli_fetch_assoc($resultado)) {
echo $fila["idEspecialidad"] . "<br>";
echo $fila["descripcionEspecialidad"] . "<br>"; }


mysqli_close($conexion);


?>