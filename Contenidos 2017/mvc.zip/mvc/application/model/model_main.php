<?php

class Model_Main extends Model{

}