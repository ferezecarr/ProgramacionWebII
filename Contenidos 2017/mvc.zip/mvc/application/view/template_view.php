<!DOCTYPE html>
<head>
    <meta charset="utf-8">
    <title>Home</title>
</head>
<body>
    <div>Cabecera</div>
    <?php include 'application/view/'.$content_view; ?>
    <div>Pie de página</div>
</body>
</html>