<h1>Listado de productos</h1>
<?php

foreach ($data as $element){
    echo "<div> Producto: $element</div>";
}

?>
<br/>
<br/>
