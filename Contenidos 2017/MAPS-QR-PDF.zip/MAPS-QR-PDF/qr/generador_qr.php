<?php

include("Conectarbd.php");
include("phpqrcode/qrlib.php");

$datos = "Nombre:Cachocfhdsfghsdfhdgf";
QRcode::png($datos,false,QR_ECLEVEL_Q,8);


QRcode::png('xdlfjhsdfljghsfd','cacho.png');





?>
