<?php
include("/inc/vr-bd.php");
$letras=trim($_GET['letras']);
$tabla=trim($_GET["tabla"]);
$clave=trim($_GET["clave"]);
$base = new BD;
$conexion = $base->Conectar();
$sql = "SELECT * FROM " . $tabla . " where " . $clave . " = '" . $letras . "' ";
$resultado = $base->Cueriar($sql, $conexion);
$devuelve = "";
while ($row = mysql_fetch_row($resultado)) {
	$devuelve = $devuelve . $row[0] . "|" . $row[1] ;
}
echo $devuelve;
?>

