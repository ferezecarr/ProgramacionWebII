<?php
    define( "PATH_CLASS" , "./PHP/Path.php");
    define( "PATH_FILE"  , "./config/path.ini");
    require_once(PATH_CLASS);
    Path::init(PATH_FILE);

    require_once(Path::getPath("includes","phpqrcode/qrlib.php") );
    QRcode::png('A trabajar sobre el tp final de segurolandia!!');

?>