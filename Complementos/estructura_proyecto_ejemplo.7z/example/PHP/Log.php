<?php

class Log {

    /**
     * @param string $from     Origen del mensaje (clase, funcion, etc)
     * @param string $message  Mensaje principal
     * @param string $error    Mensaje o codigo de error
     */
    public static function error($from, $message, $error = '') {

        self::logger($from, "ERROR", $message, $error);

    }

    /**
     * @param string $from     Origen del mensaje (clase, funcion, etc)
     * @param string $message  Mensaje principal
     * @param string $warning  Mensaje de advertencia
     */
    public static function warning($from, $message, $warning = '') {

        self::logger($from, "WARNING", $message, $warning);

    }

    /**
     * @param string $from     Origen del mensaje (clase, funcion, etc)
     * @param string $message  Mensaje informativo
     */
    public static function info($from, $message) {

        self::logger($from, "INFO", $message);

    }

    /**
     * Metodo privado que realiza efectivamente el log
     * @param string $from  Origen del mensaje (clase, funcion, etc)
     * @param string $type  Tipo de mensaje (Error,Warning,Info)
     * @param string $message  Mensaje principal
     * @param string $externalMessage   Mensaje brindado por otra fuente
     */
    private static function logger($from, $type, $message, $externalMessage = ''){

        if($externalMessage != '' )
            $logMessage = sprintf("[%-19s][%-7s][%-10s] %s\n%s", date('d/m/Y H:i:s') , $type, $from, $message, $externalMessage);
        else
            $logMessage = sprintf("[%-19s][%-7s][%-10s] %s\n", date('d/m/Y H:i:s') , $type, $from, $message);

        self::writeFile($logMessage);

    }

    /**
     * Escribe un mensaje en el archivo de log.
     * @param string $logMessage Mensaje de log.
     */
    private static function writeFile($logMessage) {

        $logFilePath = Path::getPath("log") . date('Ymd') . ".log"  ;

        $file = fopen( $logFilePath , "a");

        fwrite($file, $logMessage);

        fclose($file);
    }

}