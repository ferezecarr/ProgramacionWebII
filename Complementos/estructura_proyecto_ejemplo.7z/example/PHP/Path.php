<?php
/**
 * Class Path
 * Carga y contiene las rutas utilizadas en el proyecto y verifica que sean correctas.
 */
define( ERROR_PAGE , "error.php" );
class Path {

    private static $paths;

    /**
     * Carga el archivo de configuracion con las rutas.
     * @param string $pathsFile Ruta del archivo de configuracion
     */
    public static function init($pathsFile) {
        self::$paths = parse_ini_file($pathsFile);
    }


    /**
     * Devuelve la ruta real de un archivo.
     * @param string $path Directorio solicitado (ej: helpers, recursos, modelo_foro)
     * @param string $file Nombre del archivo ubicado en el directorio anterior
     * @return string Ruta real
     */
    public static function getPath($path, $file = "") {

        $path = self::generatePath($path, $file);

        if ( $path != FALSE){
            return $_SERVER['DOCUMENT_ROOT'] . $path;
        }
        else{
            header("redirect:" . ERROR_PAGE );
            exit;
        }
    }

    /**
     * Devuelve la ruta de un archivo en formato HTTP.
     * @param string $path Directorio solicitado
     * @param string $file Nombre del archivo ubicado en el directorio anterior
     * @return string Ruta HTTP
     */
    public static function getLink($path, $file = "") {

        $path = self::generatePath($path, $file);

        if ( $path != FALSE){
            return "http://" . $_SERVER['HTTP_HOST'] . $path;
        }
        else{
            header("redirect:" . ERROR_PAGE );
            exit;
        }
    }

    /**
     * Devuelve la ruta de un archivo CSS de estilos en formato HTTP.
     * @param string $cssFileName Nombre del archivo CSS
     * @return string Ruta HTTP del css
     */
    public static function getStyle($cssFileName) {

        $path = self::generatePath("css", $cssFileName);

        if ( $path != FALSE){
            return "http://" . $_SERVER['HTTP_HOST'] . $path;
        }
        else{
            header("redirect:" . ERROR_PAGE );
            exit;
        }
    }

    /**
     * Devuelve la ruta de un archivo JS de scripts en formato HTTP.
     * @param string $jsFileName Nombre del archivo CSS
     * @return string Ruta HTTP del js
     */
    public static function getScript($jsFileName) {

        $path = self::generatePath("script", $jsFileName);

        if ( $path != FALSE){
            return "http://" . $_SERVER['HTTP_HOST'] .  $path;
        }
        else{
            header("redirect:" . ERROR_PAGE );
            exit;
        }
    }

    /**
     * Devuelve la ruta de la imagen en formato HTTP.
     * @param string $imageFileName Nombre del archivo CSS
     * @return string Ruta HTTP de la imagen
     */
    public static function getImage($imageFileName) {

        $path = self::generatePath("images", $imageFileName);

        if ( $path != FALSE){
            return "http://" . $_SERVER['HTTP_HOST'] .  $path;
        }
        else{
            header("redirect:" . ERROR_PAGE );
            exit;
        }
    }

    /**
     * Valida si los parametros y la ruta solicitada existen y devuelve la ruta.
     * @param string $path Directorio solicitado
     * @param string $file Nombre del archivo ubicado en el directorio anterior
     * @return string Ruta completa
     */
    private static function generatePath($path, $file) {

        $validPath = FALSE;

        if (array_key_exists($path, self::$paths)) {

            $fullPath = self::$paths["root"] . self::$paths[$path] . $file;

            if (file_exists( $_SERVER['DOCUMENT_ROOT'] . $fullPath )) {
                $validPath = TRUE;
            }
        }

        if ($validPath)
            return $fullPath;
        else
            return $validPath;

    }
}