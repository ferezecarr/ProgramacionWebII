<?php

class Config {

    private static $config;

    public static function init($configFile) {
        self::$config = parse_ini_file($configFile, true);
    }

    public static function getParam($section, $param) {
        return self::$config[$section][$param];
    }
}

?>