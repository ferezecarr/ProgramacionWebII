<html>
    <head>
        <link rel="stylesheet" type="text/css" href="<?php echo Path::getStyle("style.css") ?>" />

        <script src="<?php echo Path::getLink("includes", "lightbox/js/jquery-1.11.0.min.js") ?>"></script>
        <script src="<?php echo Path::getLink("includes", "lightbox/js/lightbox.min.js") ?>"></script>
        <link  href="<?php echo Path::getLink("includes", "lightbox/css/lightbox.css") ?>" rel="stylesheet" />

        <script type="text/javascript">
        </script>
    </head>
    <body>
        <div class="header">
            <p>CABECERA DE WEB DE EJEMPLO</p>
        </div>
        <div class="content">