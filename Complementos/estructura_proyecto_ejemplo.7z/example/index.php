<?php
    //Las siguientes lineas cargan los objetos Config y Path
    //entre otras inicializaciones básicas para nuestra web como cargar el header y footer
    session_start();

    define( "PATH_CLASS" , "./PHP/Path.php");
    define( "PATH_FILE"  , "./config/path.ini");

    require_once(PATH_CLASS);
    Path::init(PATH_FILE);

    require_once(Path::getPath("php","Log.php"));
    
    require_once(Path::getPath("php","Config.php"));
    Config::init(Path::getPath("config","config.ini"));

    //CARGA DE HEADER
    include( Path::getPath("html","header.php") );



    /*  --------------------------------------------------------------------------------------- */
    /*  ------------------------------- CONTENIDO DEL EJEMPLO --------------------------------- */
    /*  --------------------------------------------------------------------------------------- */

    echo "<h3>Carga de imagen mediante Path::getImage</h3>";
    echo "<img src='" .  Path::getImage("unlam.gif") . "' />";

    echo "<h3>C&oacute;digo QR</h3>";
    echo "<img src='ejemploQr.php' width='100px' height='100px'/>";

    echo "<h3>Link de llamada</h3>";
    echo "<a href='tel:44444444'>Llamame!</a>";

    echo "<h3>Video de camara ip</h3>";
    echo "<a href='http://webcam.hotelbibionepalace.it/mjpg/video.mjpg' data-lightbox='Mi ipCam 1' data-title='Mi ipCam 1'>Cam1</a>";

    Log::info("index.php", "log de ejemplo" );

    //CARGA DE FOOTER
    include( Path::getPath("html","footer.php") );
?>