<!DOCTYPE html>
<html>
   
   <head>
      <script src = "https://maps.googleapis.com/maps/api/js"></script>
      <!--<script src = "https://maps.googleapis.com/maps/api/js?language=zh-Hans"></script>-->
      <script>
         function loadMap() {
            var mapOptions = {
               center:new google.maps.LatLng(-34.670388,-58.562392), 
               zoom:12, 
               mapTypeId:google.maps.MapTypeId.ROADMAP
	       //disableDefaultUI: true
               //panControl: true,
               //zoomControl: true,
               //scaleControl: true,
               //mapTypeControl:true,
               //streetViewControl:true,
               //overviewMapControl:true,
               //rotateControl:true
		// SATELLITE
		// HYBRID
		// TERRAIN
		//  zoom: 0 12
            };
            var map = new google.maps.Map(document.getElementById("sample"),mapOptions);

	//	var marker = new google.maps.Marker({
	//	position: new google.maps.LatLng(-34.670388,-58.562392),
	//	map: map,
	//	animation:google.maps.Animation.Drop,
        //       draggable:true,
        //       icon:'top.png'
	//	}); 

            //marker.setMap(map);
            
          //  var infowindow = new google.maps.InfoWindow({
            //   content:"UNLaM"
           // });
				
           // infowindow.open(map,marker);

//	  var geocoder = new google.maps.Geocoder();
// 	  google.maps.event.addListener(map, 'click', function(event) {
//		geocoder.geocode({
//				'latLng': event.latLng
//				}, function(results, status) {
//				if (status == google.maps.GeocoderStatus.OK) {
//				if (results[0]) {
//					alert(results[0].formatted_address);
//					}
//				}
//			});
//		});

	
//marker.setMap(null);

        }

         google.maps.event.addDomListener(window, 'load', loadMap);
      </script>
   </head>
   <body>

<h1>Mapa Simple </h1>

      <div id = "sample" style = "width:580px; height:400px;"></div>

</body>
</html>