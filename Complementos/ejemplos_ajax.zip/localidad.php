<?php
$provincia = $_GET["provincia"];
$conexion = mysqli_connect("127.0.0.1","root","","ejemplo");
$sql = "SELECT id,ciudad_nombre FROM ciudad WHERE provincia_id = " . $provincia;
$resultado = mysqli_query($conexion, $sql);
while($fila = mysqli_fetch_assoc($resultado)){
    echo "<option value='" . $fila["id"] . "'>" . $fila["ciudad_nombre"] . "</option>";
}
?>
