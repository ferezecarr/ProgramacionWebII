<html>
<head>
<script type="text/javascript" src="jquery-1.11.0.min.js"></script>
<script type="text/javascript">

    $(function() {

        $("#provincia").change(function() {
            var id = $(this).val();
            var parametro = 'provincia='+ id;

            $.ajax ({
                type: "GET",
                url: "localidad.php",
                data: parametro,
                cache: false,
                success:
                    function(html){
                        $("#localidad").html(html);
                    }
            });
        }).trigger("change");

    });

</script>
    <body>
        <?php

        $conexion = mysqli_connect("127.0.0.1","root","","ejemplo");
        $sql = "SELECT * FROM provincia;";
        $resultado = mysqli_query($conexion, $sql);
        echo "<select id='provincia' onchange='buscaLocalidad(this.value)'>";
        while($fila = mysqli_fetch_assoc($resultado)){
            echo "<option value='"  . $fila["id"] . "'>" . $fila["provincia_nombre"] . "</option>";
        }
        echo "</select><br />";
        echo "<select id='localidad'></select>";
        ?>
</body>
</html>